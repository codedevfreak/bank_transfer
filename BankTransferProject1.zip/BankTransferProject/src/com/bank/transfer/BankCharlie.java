package com.bank.transfer;

import java.math.BigDecimal;
import java.util.Map;

public interface BankCharlie {
    Map<String, BigDecimal> balance();
    int transferIDR(String account, int transferType, String bankCode, BigDecimal amount);
    int transferUSD(String account, int transferType, String bankCode, BigDecimal amount);
	boolean send(String accountTo, String bankCodeTo, BigDecimal amount, String currency);
}
