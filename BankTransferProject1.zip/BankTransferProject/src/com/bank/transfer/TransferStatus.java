package com.bank.transfer;

public class TransferStatus {
    String status;
    String message;

    public TransferStatus(String status, String message) {
        this.status = status;
        this.message = message;
    }
}
