package com.bank.transfer;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        BankTransfer.startTransferService();
    }
}
