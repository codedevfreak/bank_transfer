package com.bank.transfer;

import java.math.BigDecimal;

public interface BankAlpha {
    BigDecimal checkBalance(String currency);
    boolean send(String account, String bankCode, BigDecimal amount, String currency);
	void transferInhouse(String accountTo, BigDecimal amount, String currency);
	void transferOnline(String accountTo, String bankCodeTo, BigDecimal amount, String currency);
}
