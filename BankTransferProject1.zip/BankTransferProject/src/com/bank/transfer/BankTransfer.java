package com.bank.transfer;

import java.math.BigDecimal;
import java.time.LocalTime;

public class BankTransfer {

    private static BankAlpha bankAlpha;
    private static BankBeta bankBeta;
    private static BankCharlie bankCharlie;

    public static void startTransferService() throws InterruptedException {
        while (true) {
            Transfer transfer = getPendingTransfer();
            if (transfer != null) {
                boolean success = sendMoney(transfer);
                TransferStatus status = success ? new TransferStatus("Success", "Transfer completed successfully.")
                        : new TransferStatus("Failed", "Transfer failed.");
                setTransferStatus(status);
            }
            Thread.sleep(5 * 60 * 1000);
        }
    }

    private static Transfer getPendingTransfer() {
        return new Transfer("12345", "67890", "A01IDJA", new BigDecimal("1000"), "IDR", "online");
    }

    private static boolean sendMoney(Transfer transfer) {
        LocalTime now = LocalTime.now();
        String currency = transfer.currency;
        String bankCodeTo = transfer.bankCodeTo;

        if (transfer.type.equals("online")) {
            if (now.isBefore(LocalTime.of(4, 0))) {
                return false;
            } else if (now.isBefore(LocalTime.of(10, 0))) {
                return tryTransfer(bankAlpha, bankBeta, bankCharlie, transfer, currency);
            } else if (now.isBefore(LocalTime.of(17, 0))) {
                return tryTransfer(bankBeta, bankCharlie, bankAlpha, transfer, currency);
            } else if (now.isBefore(LocalTime.of(22, 0))) {
                if (currency.equals("USD")) {
                    return false;
                } else {
                    return tryTransfer(bankCharlie, bankAlpha, bankBeta, transfer, currency);
                }
            } else {
                return tryTransfer(bankBeta, null, null, transfer, currency);
            }
        } else if (transfer.type.equals("inhouse")) {
            return bankAlpha.send(transfer.accountTo, bankCodeTo, transfer.amount, currency);
        }
        return false;
    }

    private static boolean tryTransfer(BankAlpha bankAlpha2, BankBeta bankBeta2, BankCharlie bankCharlie2,
			Transfer transfer, String currency) {
		// TODO Auto-generated method stub
		return false;
	}

	private static boolean tryTransfer(BankBeta bankBeta2, BankCharlie bankCharlie2, BankAlpha bankAlpha2,
			Transfer transfer, String currency) {
		// TODO Auto-generated method stub
		return false;
	}

	private static boolean tryTransfer(BankCharlie bankCharlie2, BankAlpha bankAlpha2, BankBeta bankBeta2, Transfer transfer, String currency) {
        if (bankCharlie2 != null && bankCharlie2.send(transfer.accountTo, transfer.bankCodeTo, transfer.amount, currency)) {
            return true;
        } else if (bankAlpha2 != null) {
            if (transfer.bankCodeTo.equals("A01IDJA")) {
			    bankAlpha2.transferInhouse(transfer.accountTo, transfer.amount, currency);
			} else {
			    bankAlpha2.transferOnline(transfer.accountTo, transfer.bankCodeTo, transfer.amount, currency);
			}
			return true;
        } else if (bankBeta2 != null) {
            int result = (currency.equals("IDR")) ? bankBeta2.transferIDR(transfer.accountTo, 2, transfer.bankCodeTo, transfer.amount)
                    : bankBeta2.transferUSD(transfer.accountTo, 2, transfer.bankCodeTo, transfer.amount);
            return result == 1;
        }
        return false;
    }

    private static void setTransferStatus(TransferStatus status) {
        System.out.println("Transfer Status: " + status.status + " - " + status.message);
    }
}
