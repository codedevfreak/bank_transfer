package com.bank.transfer;

import java.math.BigDecimal;

public interface BankBeta {
    BigDecimal transferInhouse(String account, BigDecimal amount, String currency) throws TransactionFailedException;
    BigDecimal transferOnline(String account, String bankCode, BigDecimal amount, String currency) throws TransactionFailedException;
	int transferIDR(String accountTo, int i, String bankCodeTo, BigDecimal amount);
	int transferUSD(String accountTo, int i, String bankCodeTo, BigDecimal amount);
}
