package com.bank.transfer;

import java.math.BigDecimal;

public class Transfer {
    String accountFrom;
    String accountTo;
    String bankCodeTo;
    BigDecimal amount;
    String currency;
    String type; // "inhouse" atau "online"

    public Transfer(String accountFrom, String accountTo, String bankCodeTo, BigDecimal amount, String currency, String type) {
        this.accountFrom = accountFrom;
        this.accountTo = accountTo;
        this.bankCodeTo = bankCodeTo;
        this.amount = amount;
        this.currency = currency;
        this.type = type;
    }
}
